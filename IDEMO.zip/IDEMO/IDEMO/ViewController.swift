//
//  ViewController.swift
//  IDEMO
//
//  Created by Entab Infotech Pvt Ltd on 09/10/18.
//  Copyright © 2018 Entab Infotech Pvt Ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtPasword: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    @IBOutlet weak var txtName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        txtName.text = "abc"
        txtPasword.text = "Abc@12345"
        txtemail.text = "A@gmail.com"
        txtMobile.text = "9990358582"
    }

    func isValidEmail(testStr22:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr22)
    }
    
    func isValidPassword(testStr33:String) -> Bool
    {
        let passwordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&#])[A-Za-z\\d$@$!%*?&#]{8,}"
        let passwordTest = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        return passwordTest.evaluate(with: testStr33)
    }
    
    
    
    
    
    @IBAction func clkToNext(_ sender: Any)
    {
        let phoneRegex = "[2356789][0-9]{6}([0-9]{3})?"
        let testmob = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        
        let getEmailstr = isValidEmail(testStr22: txtemail.text!)
        print(getEmailstr)
        
        let checkValidateBool = self.isValidPassword(testStr33: txtPasword.text!)
        print(checkValidateBool)
        
       
        
        if txtName.text == "" || txtMobile.text == "" || txtemail.text == "" || txtPasword.text == ""
        {
            let alert = UIAlertController(title: "", message: "Feild Cant be empty." as String, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if testmob.evaluate(with: txtMobile.text) == false
        {
            let alert = UIAlertController(title: "", message: "Please Provide Valid Mobile Number", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }

        else if getEmailstr==false
        {
            let alert = UIAlertController(title: "", message: "Email address not valid", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if checkValidateBool==false
        {
            let alert = UIAlertController(title: "", message: "Password not valid", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ServiceViewController") as! ServiceViewController
             vc.myJson6 = "Arpit saini"
            navigationController?.pushViewController(vc,animated: true)
        }
    }

}

