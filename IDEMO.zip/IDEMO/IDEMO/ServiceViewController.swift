//
//  ServiceViewController.swift
//  IDEMO
//
//  Created by Entab Infotech Pvt Ltd on 09/10/18.
//  Copyright © 2018 Entab Infotech Pvt Ltd. All rights reserved.
//

import UIKit

class ServiceViewController: UIViewController,UITableViewDelegate, UITableViewDataSource
{
    
    var myJson6 = String()
       var myJson = NSArray()
    
    @IBOutlet weak var tblSecond: UITableView!
    @IBOutlet weak var tblFirst: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
      print(myJson6)
       
        if Reachability.isConnectedToNetwork() == true
        {
            print("Internet connection OK")
           // webServices()
        }
        else
        {
            print("Internet connection FAILED")
            let alert = UIAlertController(title: "", message: "Internet Connection Not Found." as String, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }

    
    
    
    func webService() -> Void {
        let Url = String(format: "your url")
        guard let serviceUrl = URL(string: Url) else { return }
        //        let loginParams = String(format: LOGIN_PARAMETERS1, "test", "Hi World")
        let parameterDictionary = ["username" : "@kilo_laco", "tweet" : "Hi World"]
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "POST"
        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameterDictionary, options: []) else {
            return
        }
        request.httpBody = httpBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response
            {
                print(response)
            }
            if let data = data
            {
                do
                {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                }
                catch
                {
                    print(error)
                }
            }
            }.resume()
        
    }
    
    
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView==tblFirst
        {
           //return myJson6.count
            return 5
        }
        else
        {
            return 5
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
    if tableView==tblFirst
    {
        var cell : FirstTableViewCell! = tableView.dequeueReusableCell(withIdentifier: "FirstTableViewCell") as! FirstTableViewCell
        if(cell == nil)
        {
            cell = Bundle.main.loadNibNamed("FirstTableViewCell", owner: self, options: nil)?[0] as! FirstTableViewCell;
        }
        
        cell.lbl11111?.text = String(format:"%d",indexPath.row+1)
        //  cell.lbl_CallStatus.text=((self.myJson[indexPath.row] as AnyObject) .value(forKey: "CallStatus"))  as? String
        return cell as FirstTableViewCell
    }
    else
    {
        var cell : SecondTableViewCell! = tableView.dequeueReusableCell(withIdentifier: "SecondTableViewCell") as! SecondTableViewCell
        if(cell == nil)
        {
            cell = Bundle.main.loadNibNamed("SecondTableViewCell", owner: self, options: nil)?[0] as! SecondTableViewCell;
        }
        
        cell.lbl22222?.text = String(format:"%d",indexPath.row+1)
        return cell as SecondTableViewCell
    }
}

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if tableView==tblFirst
        {
             print(indexPath.row);
        }
        else
        {
             print(indexPath.row);
        }
    }
}
